package com.myspring.pro27.member.controller;

import com.myspring.pro27.member.vo.MemberVO;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface MemberController {
    public ModelAndView listMembers(HttpServletRequest request,
                                    HttpServletResponse response) throws Exception;
    public ModelAndView addMember(@ModelAttribute("member") MemberVO member,
                                  HttpServletRequest request,
                                  HttpServletResponse response) throws Exception;
    public ModelAndView removeMember(@RequestParam("id") String id,
                                     HttpServletRequest request,
                                     HttpServletResponse response) throws Exception;
}
